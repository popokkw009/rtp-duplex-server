#!/bin/bash
set -e

APP_DIR="/opt/rtp-duplex-server"

echo "==> Instalasi RTP Duplex Server"

if ! command -v docker &> /dev/null; then
  echo "Docker belum ada!"
  exit 1
fi
if ! command -v docker compose &> /dev/null; then
  echo "Docker Compose belum ada!"
  exit 1
fi

sudo rm -rf $APP_DIR
sudo mkdir -p $APP_DIR
sudo cp -r . $APP_DIR
cd $APP_DIR

docker compose up -d --build

echo "✅ Instalasi selesai!"
echo "GUI: http://<IP-VPS>:8081"
echo "API: http://<IP-VPS>:8080"
