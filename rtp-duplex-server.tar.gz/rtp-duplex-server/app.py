import subprocess, time, os, glob
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse

app = FastAPI()
RECORD_DIR = "recordings"
os.makedirs(RECORD_DIR, exist_ok=True)

@app.post("/record/start")
def start_recording(port: int = 5004, duration: int = 10):
    filename = time.strftime("recording-%Y-%m-%d_%H-%M-%S.wav")
    filepath = os.path.join(RECORD_DIR, filename)

    cmd = [
        "ffmpeg", "-y",
        "-i", f"rtp://0.0.0.0:{port}",
        "-t", str(duration),
        "-acodec", "pcm_s16le",
        "-ar", "48000",
        "-ac", "2",
        filepath
    ]
    subprocess.Popen(cmd)

    return {"message": f"Rekaman dimulai di port {port}", "file": filename}

@app.get("/record/list")
def list_recordings():
    files = sorted(glob.glob(os.path.join(RECORD_DIR, "*.wav")))
    return [{"file": os.path.basename(f), "size": os.path.getsize(f)} for f in files]

@app.get("/record/download/{filename}")
def download_recording(filename: str):
    filepath = os.path.join(RECORD_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File tidak ditemukan")
    return FileResponse(filepath, filename=filename)

@app.delete("/record/delete/{filename}")
def delete_recording(filename: str):
    filepath = os.path.join(RECORD_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(status_code=404, detail="File tidak ditemukan")
    os.remove(filepath)
    return {"message": f"{filename} berhasil dihapus"}
