#!/bin/bash
set -e
APP_DIR="/opt/rtp-duplex-server"

cd $APP_DIR
docker compose down -v
rm -rf $APP_DIR

echo "✅ Uninstall selesai"
