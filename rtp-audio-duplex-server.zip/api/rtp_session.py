import asyncio
import signal
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional
import subprocess

from ffmpeg_sdp import write_sdp


@dataclass
class Flow:
    name: str
    in_ip: str
    in_port: int
    out_ip: str
    out_port: int
    codec: str
    record_path: Optional[Path] = None
    sdp_file: Optional[Path] = None
    rec_proc: Optional[subprocess.Popen] = None


@dataclass
class Session:
    id: str
    label: str
    a_ip: str
    a_port: int
    b_ip: str
    b_port: int
    send_a_ip: str
    send_a_port: int
    send_b_ip: str
    send_b_port: int
    codec: str
    started_at: float = field(default_factory=time.time)
    flows: Dict[str, Flow] = field(default_factory=dict)

    async def start(self, recordings_dir: Path):
        self.flows["AtoB"] = await self._spawn_forwarder(
            name="AtoB",
            in_ip=self.a_ip, in_port=self.a_port,
            out_ip=self.send_b_ip, out_port=self.send_b_port,
            codec=self.codec,
            recordings_dir=recordings_dir,
        )
        self.flows["BtoA"] = await self._spawn_forwarder(
            name="BtoA",
            in_ip=self.b_ip, in_port=self.b_port,
            out_ip=self.send_a_ip, out_port=self.send_a_port,
            codec=self.codec,
            recordings_dir=recordings_dir,
        )

    async def stop(self):
        for f in self.flows.values():
            if f.rec_proc and f.rec_proc.poll() is None:
                try:
                    f.rec_proc.send_signal(signal.SIGINT)
                except Exception:
                    pass
                try:
                    f.rec_proc.terminate()
                except Exception:
                    pass
        await asyncio.sleep(0.2)

    async def _spawn_forwarder(self, name: str, in_ip: str, in_port: int, out_ip: str, out_port: int, codec: str, recordings_dir: Path) -> Flow:
        loop = asyncio.get_running_loop()

        class Forwarder(asyncio.DatagramProtocol):
            def connection_made(self, transport):
                self.transport = transport
            def datagram_received(self, data, addr):
                self.transport.sendto(data, (out_ip, out_port))

        transport, protocol = await loop.create_datagram_endpoint(
            lambda: Forwarder(), local_addr=('0.0.0.0', in_port)
        )

        rec_file = recordings_dir / f"{int(time.time())}_{name}_rec_{time.strftime('%Y-%m-%d_%H-%M-%S')}.wav"
        sdp_path = recordings_dir / f"{name}_{in_port}.sdp"
        write_sdp(sdp_path, codec=codec, listen_ip='0.0.0.0', rtp_port=in_port)
        ff_cmd = [
            'ffmpeg', '-hide_banner', '-nostats', '-y',
            '-protocol_whitelist', 'file,rtp,udp',
            '-i', str(sdp_path),
            '-acodec', 'pcm_s16le', '-ac', '1', '-ar', '8000',
            str(rec_file)
        ]
        rec_proc = subprocess.Popen(ff_cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        flow = Flow(
            name=name,
            in_ip=in_ip, in_port=in_port,
            out_ip=out_ip, out_port=out_port,
            codec=codec,
            record_path=rec_file,
            sdp_file=sdp_path,
            rec_proc=rec_proc,
        )
        return flow
