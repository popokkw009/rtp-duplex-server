from pathlib import Path

PT_MAP = {
    "pcmu": {"pt": 0,   "rate": 8000,  "fmtp": None},
    "opus": {"pt": 111, "rate": 48000, "fmtp": "minptime=10;useinbandfec=1"},
    "pcm16": {"pt": 10, "rate": 8000,  "fmtp": None},
}

def make_sdp(codec: str, listen_ip: str, rtp_port: int) -> str:
    c = PT_MAP.get(codec)
    if not c:
        raise ValueError(f"Unsupported codec for SDP: {codec}")
    pt = c["pt"]
    rate = c["rate"]
    fmtp = c["fmtp"]
    lines = [
        "v=0",
        "o=- 0 0 IN IP4 0.0.0.0",
        "s=RTP Session",
        f"c=IN IP4 {listen_ip}",
        f"t=0 0",
        f"m=audio {rtp_port} RTP/AVP {pt}",
        f"a=rtpmap:{pt} {'OPUS' if codec=='opus' else ('PCMU' if codec=='pcmu' else 'L16')}/{rate}",
    ]
    if fmtp:
        lines.append(f"a=fmtp:{pt} {fmtp}")
    lines.append("a=recvonly")
    return "\n".join(lines) + "\n"


def write_sdp(path: Path, codec: str, listen_ip: str, rtp_port: int) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(make_sdp(codec, listen_ip, rtp_port))
    return path
