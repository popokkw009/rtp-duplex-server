import uuid
from pathlib import Path
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from rtp_session import Session

APP_TITLE = "RTP Audio Duplex Server"
RECORDINGS_DIR = Path("/app/recordings")
RECORDINGS_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title=APP_TITLE)

SESSIONS: Dict[str, Session] = {}


class CreateSessionReq(BaseModel):
    a_ip: str = Field(..., description="Source A IP (sending RTP to us)")
    a_port: int = Field(..., description="Source A RTP port (we listen here)")

    b_ip: str = Field(..., description="Source B IP (sending RTP to us)")
    b_port: int = Field(..., description="Source B RTP port (we listen here)")

    send_a_ip: str = Field(..., description="Target IP to send B->A RTP")
    send_a_port: int = Field(..., description="Target port to send B->A RTP")

    send_b_ip: str = Field(..., description="Target IP to send A->B RTP")
    send_b_port: int = Field(..., description="Target port to send A->B RTP")

    codec: str = Field("pcmu", description="Codec hint for SDP/record (pcmu|opus|pcm16)")
    label: Optional[str] = Field(None, description="Optional label")


class SessionInfo(BaseModel):
    id: str
    label: Optional[str]
    codec: str
    a: str
    b: str
    send_to_a: str
    send_to_b: str
    started_at: float


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/sessions", response_model=SessionInfo)
async def create_session(req: CreateSessionReq):
    sid = str(uuid.uuid4())[:8]
    sess = Session(
        id=sid,
        label=req.label or "",
        a_ip=req.a_ip,
        a_port=req.a_port,
        b_ip=req.b_ip,
        b_port=req.b_port,
        send_a_ip=req.send_a_ip,
        send_a_port=req.send_a_port,
        send_b_ip=req.send_b_ip,
        send_b_port=req.send_b_port,
        codec=req.codec.lower(),
    )
    await sess.start(RECORDINGS_DIR)
    SESSIONS[sid] = sess
    return SessionInfo(
        id=sid,
        label=sess.label,
        codec=sess.codec,
        a=f"in A: {sess.a_ip}:{sess.a_port}",
        b=f"in B: {sess.b_ip}:{sess.b_port}",
        send_to_a=f"B->A out: {sess.send_a_ip}:{sess.send_a_port}",
        send_to_b=f"A->B out: {sess.send_b_ip}:{sess.send_b_port}",
        started_at=sess.started_at,
    )


@app.get("/sessions", response_model=List[SessionInfo])
async def list_sessions():
    out: List[SessionInfo] = []
    for s in SESSIONS.values():
        out.append(SessionInfo(
            id=s.id,
            label=s.label,
            codec=s.codec,
            a=f"in A: {s.a_ip}:{s.a_port}",
            b=f"in B: {s.b_ip}:{s.b_port}",
            send_to_a=f"B->A out: {s.send_a_ip}:{s.send_a_port}",
            send_to_b=f"A->B out: {s.send_b_ip}:{s.send_b_port}",
            started_at=s.started_at,
        ))
    return out


@app.delete("/sessions/{sid}")
async def stop_session(sid: str):
    s = SESSIONS.get(sid)
    if not s:
        raise HTTPException(404, "session not found")
    await s.stop()
    del SESSIONS[sid]
    return {"stopped": sid}


@app.get("/recordings")
async def list_recordings():
    files = []
    for p in sorted(RECORDINGS_DIR.glob("*.wav")):
        files.append({
            "name": p.name,
            "size": p.stat().st_size,
            "mtime": p.stat().st_mtime,
        })
    return files


@app.get("/recordings/{name}")
async def download_recording(name: str):
    from fastapi.responses import FileResponse
    p = RECORDINGS_DIR / name
    if not p.exists():
        raise HTTPException(404, "not found")
    return FileResponse(str(p), media_type="audio/wav", filename=name)
